# StudySnap - AI-Powered Flashcard Generator

StudySnap is a full-stack SaaS application that converts long videos and written notes into concise, high-quality flashcards designed for effective studying.

## Features

- **AI-Powered Flashcard Generation**: Upload YouTube videos, PDFs, or paste text to automatically generate study-optimized flashcards
- **User Authentication**: Secure email/password authentication with JWT
- **Subscription Management**: Free tier (5 flashcards/week) and Unlimited plan (£2.99/week) with Stripe integration
- **Weekly Usage Tracking**: Automatic reset of free tier limits every Monday
- **Clean Study Interface**: Interactive flashcard viewer with flip animations and keyboard navigation
- **Mobile Responsive**: Works seamlessly on desktop, tablet, and mobile devices

## Tech Stack

### Frontend
- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS + shadcn/ui components
- Zustand (state management)
- React Router
- Axios (API client)
- Stripe.js (payments)

### Backend
- Node.js + Express + TypeScript
- PostgreSQL (database)
- Prisma ORM
- JWT Authentication
- OpenAI GPT-4o-mini (flashcard generation)
- Stripe (subscription management)
- Multer (file uploads)

## Project Structure

```
/mnt/okcomputer/output/
├── app/                    # Frontend React application
│   ├── src/
│   │   ├── api/           # API client functions
│   │   ├── components/    # UI components (shadcn/ui)
│   │   ├── pages/         # Page components
│   │   ├── stores/        # Zustand state stores
│   │   └── ...
│   └── package.json
│
├── backend/               # Backend Express application
│   ├── src/
│   │   ├── controllers/   # Route controllers
│   │   ├── middleware/    # Express middleware
│   │   ├── routes/        # API routes
│   │   ├── services/      # Business logic (OpenAI, Stripe, etc.)
│   │   ├── utils/         # Utility functions
│   │   └── server.ts      # Entry point
│   ├── prisma/
│   │   └── schema.prisma  # Database schema
│   └── package.json
│
└── README.md
```

## Prerequisites

- Node.js 18+ 
- PostgreSQL 14+
- OpenAI API key
- Stripe account (for payments)
- YouTube Data API (optional, for video titles)

## Environment Variables

### Backend (.env)
```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/studysnap?schema=public"

# JWT
JWT_SECRET="your-super-secret-jwt-key"
JWT_EXPIRES_IN="7d"

# Stripe
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..."
STRIPE_PRICE_ID="price_..."  # £2.99/week price ID

# OpenAI
OPENAI_API_KEY="sk-..."

# Server
PORT=5000
NODE_ENV="development"
CLIENT_URL="http://localhost:5173"
```

### Frontend (.env)
```env
VITE_API_URL=http://localhost:5000/api
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...
```

## Setup Instructions

### 1. Database Setup

```bash
# Create PostgreSQL database
createdb studysnap

# Or using psql
psql -c "CREATE DATABASE studysnap;"
```

### 2. Backend Setup

```bash
cd /mnt/okcomputer/output/backend

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env
# Edit .env with your credentials

# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate dev --name init

# Start development server
npm run dev
```

The backend will start on http://localhost:5000

### 3. Frontend Setup

```bash
cd /mnt/okcomputer/output/app

# Install dependencies
npm install

# Copy environment variables
cp .env.example .env
# Edit .env with your API URL and Stripe key

# Start development server
npm run dev
```

The frontend will start on http://localhost:5173

### 4. Stripe Setup

1. Create a Stripe account at https://stripe.com
2. Get your API keys from the Stripe Dashboard
3. Create a product and price for the subscription (£2.99/week)
4. Set up the webhook endpoint:
   - Endpoint URL: `https://your-domain.com/api/subscriptions/webhook`
   - Events to listen for:
     - `checkout.session.completed`
     - `invoice.payment_succeeded`
     - `invoice.payment_failed`
     - `customer.subscription.deleted`

### 5. OpenAI Setup

1. Create an OpenAI account at https://openai.com
2. Get your API key from https://platform.openai.com/api-keys
3. Add the key to your backend `.env` file

## Building for Production

### Backend

```bash
cd /mnt/okcomputer/output/backend

# Build TypeScript
npm run build

# Start production server
npm start
```

### Frontend

```bash
cd /mnt/okcomputer/output/app

# Build for production
npm run build

# Output will be in dist/ directory
```

## Deployment

### Option 1: Railway/Render/Heroku (Recommended)

1. Push code to GitHub
2. Connect your repository to the platform
3. Set environment variables in the platform dashboard
4. Deploy!

### Option 2: VPS/Dedicated Server

```bash
# 1. Clone repository
git clone <your-repo>

# 2. Setup backend
cd studysnap/backend
npm install
npm run build

# 3. Setup frontend
cd ../app
npm install
npm run build

# 4. Use PM2 to run backend
npm install -g pm2
pm2 start dist/server.js --name studysnap-api

# 5. Serve frontend with Nginx
# Copy dist/ contents to /var/www/studysnap
# Configure Nginx to serve static files and proxy API requests
```

### Sample Nginx Configuration

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /var/www/studysnap;
        try_files $uri $uri/ /index.html;
    }

    # API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user

### Flashcards
- `POST /api/flashcards/generate/text` - Generate from text
- `POST /api/flashcards/generate/youtube` - Generate from YouTube URL
- `POST /api/flashcards/generate/file` - Generate from uploaded file
- `GET /api/flashcards` - Get all user's flashcard sets
- `GET /api/flashcards/:id` - Get specific flashcard set
- `DELETE /api/flashcards/:id` - Delete flashcard set

### Subscriptions
- `POST /api/subscriptions/checkout` - Create checkout session
- `GET /api/subscriptions/status` - Get subscription status
- `POST /api/subscriptions/cancel` - Cancel subscription
- `POST /api/subscriptions/webhook` - Stripe webhook

### Usage
- `GET /api/usage` - Get current usage stats

## Database Schema

### User
- id, email, password, name, createdAt, updatedAt

### Subscription
- id, userId, status, stripeCustomerId, stripeSubscriptionId, stripePriceId, currentPeriodStart, currentPeriodEnd

### FlashcardSet
- id, userId, title, description, sourceType, sourceUrl, createdAt, updatedAt

### Flashcard
- id, setId, front, back, order, createdAt, updatedAt

### UsageStat
- id, userId, weekStart, weekEnd, flashcardsGenerated

### Upload
- id, userId, filename, originalName, mimeType, size, path, processed

## Free Tier Limits

- Free users can generate up to 5 flashcards per week
- Weekly limit resets every Monday at midnight UTC
- Upgrade to Unlimited for £2.99/week (7-day free trial)

## Security Considerations

1. **JWT Secret**: Use a strong, random secret in production
2. **Passwords**: Bcrypt with salt rounds 12
3. **CORS**: Configure allowed origins
4. **File Uploads**: Limited to 100MB, validated mime types
5. **Stripe Webhook**: Verify webhook signatures
6. **Environment Variables**: Never commit .env files

## License

MIT License - feel free to use this for your own projects!

## Support

For issues and feature requests, please open an issue on GitHub.
