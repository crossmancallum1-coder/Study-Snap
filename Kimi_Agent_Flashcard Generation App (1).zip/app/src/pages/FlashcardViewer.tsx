import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useFlashcardStore } from '../stores/flashcardStore';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { 
  ChevronLeft, 
  ChevronRight, 
  RotateCw, 
  ArrowLeft,
  Shuffle,
  BookOpen
} from 'lucide-react';

export default function FlashcardViewer() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { currentSet, fetchSet, isLoading } = useFlashcardStore();
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [shuffledOrder, setShuffledOrder] = useState<number[]>([]);
  const [isShuffled, setIsShuffled] = useState(false);

  useEffect(() => {
    if (id) {
      fetchSet(id);
    }
  }, [id, fetchSet]);

  useEffect(() => {
    if (currentSet?.flashcards) {
      setShuffledOrder([...Array(currentSet.flashcards.length).keys()]);
    }
  }, [currentSet]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  if (!currentSet) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-slate-900">Flashcard set not found</h2>
          <Button onClick={() => navigate('/dashboard')} className="mt-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const flashcards = currentSet.flashcards;
  const totalCards = flashcards.length;
  const displayIndex = isShuffled ? shuffledOrder[currentIndex] : currentIndex;
  const currentCard = flashcards[displayIndex];
  const progress = ((currentIndex + 1) / totalCards) * 100;

  const handleNext = () => {
    if (currentIndex < totalCards - 1) {
      setIsFlipped(false);
      setTimeout(() => setCurrentIndex(currentIndex + 1), 150);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setIsFlipped(false);
      setTimeout(() => setCurrentIndex(currentIndex - 1), 150);
    }
  };

  const handleShuffle = () => {
    if (isShuffled) {
      setShuffledOrder([...Array(totalCards).keys()]);
      setIsShuffled(false);
    } else {
      const newOrder = [...Array(totalCards).keys()];
      for (let i = newOrder.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newOrder[i], newOrder[j]] = [newOrder[j], newOrder[i]];
      }
      setShuffledOrder(newOrder);
      setIsShuffled(true);
    }
    setCurrentIndex(0);
    setIsFlipped(false);
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      setIsFlipped(!isFlipped);
    } else if (e.key === 'ArrowRight') {
      handleNext();
    } else if (e.key === 'ArrowLeft') {
      handlePrevious();
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, isFlipped, totalCards]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div className="text-center">
            <h1 className="font-semibold text-slate-900 truncate max-w-xs sm:max-w-md">
              {currentSet.title}
            </h1>
            <p className="text-sm text-slate-500">
              Card {currentIndex + 1} of {totalCards}
            </p>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={handleShuffle}
            className={isShuffled ? 'text-violet-600' : ''}
          >
            <Shuffle className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress */}
        <div className="mb-8">
          <Progress value={progress} className="h-2" />
        </div>

        {/* Flashcard */}
        <div className="relative h-96 sm:h-[500px] perspective-1000">
          <div
            className={`w-full h-full transition-all duration-500 transform-style-3d cursor-pointer ${
              isFlipped ? 'rotate-y-180' : ''
            }`}
            onClick={() => setIsFlipped(!isFlipped)}
          >
            {/* Front */}
            <Card 
              className={`absolute inset-0 backface-hidden flex items-center justify-center p-8 sm:p-12 shadow-xl ${
                isFlipped ? 'opacity-0' : 'opacity-100'
              }`}
            >
              <div className="text-center max-w-2xl">
                <p className="text-sm text-slate-400 uppercase tracking-wide mb-4">Question</p>
                <h2 className="text-xl sm:text-2xl lg:text-3xl font-medium text-slate-900 leading-relaxed">
                  {currentCard.front}
                </h2>
                <p className="text-sm text-slate-400 mt-8">
                  Click or press Space to flip
                </p>
              </div>
            </Card>

            {/* Back */}
            <Card 
              className={`absolute inset-0 backface-hidden rotate-y-180 flex items-center justify-center p-8 sm:p-12 shadow-xl bg-gradient-to-br from-violet-50 to-indigo-50 ${
                isFlipped ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <div className="text-center max-w-2xl">
                <p className="text-sm text-violet-600 uppercase tracking-wide mb-4">Answer</p>
                <h2 className="text-xl sm:text-2xl lg:text-3xl font-medium text-slate-900 leading-relaxed">
                  {currentCard.back}
                </h2>
                <p className="text-sm text-slate-400 mt-8">
                  Click or press Space to flip back
                </p>
              </div>
            </Card>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4 mt-8">
          <Button
            variant="outline"
            size="lg"
            onClick={handlePrevious}
            disabled={currentIndex === 0}
          >
            <ChevronLeft className="w-5 h-5 mr-2" />
            Previous
          </Button>
          
          <Button
            variant="outline"
            size="icon"
            onClick={() => setIsFlipped(!isFlipped)}
          >
            <RotateCw className="w-5 h-5" />
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            onClick={handleNext}
            disabled={currentIndex === totalCards - 1}
          >
            Next
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>

        {/* Keyboard Shortcuts */}
        <div className="text-center mt-8 text-sm text-slate-400">
          <p>Keyboard shortcuts: ← → to navigate • Space to flip</p>
        </div>
      </main>
    </div>
  );
}
