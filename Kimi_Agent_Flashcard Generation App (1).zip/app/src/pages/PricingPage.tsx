import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { subscriptionApi } from '../api/subscription';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Brain, 
  CheckCircle, 
  Crown, 
  Zap, 
  ArrowLeft, 
  Loader2,
  AlertCircle,
  Calendar
} from 'lucide-react';

export default function PricingPage() {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const isSubscribed = user?.subscription?.status === 'ACTIVE';

  const handleSubscribe = async () => {
    if (!isAuthenticated) {
      navigate('/register');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const { url } = await subscriptionApi.createCheckout();
      window.location.href = url;
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to start checkout');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div 
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => navigate('/')}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                StudySnap
              </span>
            </div>
            <Button variant="ghost" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </div>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-slate-600">Start free, upgrade when you're ready</p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-8 max-w-2xl mx-auto">
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isSubscribed && (
          <Alert className="mb-8 max-w-2xl mx-auto bg-green-50 border-green-200">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <AlertDescription className="text-green-800">
              You're on the Unlimited plan! Your subscription is active.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Free Plan */}
          <Card className={`border-2 ${!isSubscribed ? 'border-violet-600' : 'border-slate-200'}`}>
            <CardContent className="p-8">
              {!isSubscribed && (
                <div className="inline-block bg-violet-100 text-violet-700 px-3 py-1 rounded-full text-sm font-medium mb-4">
                  Current Plan
                </div>
              )}
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Free</h2>
              <p className="text-slate-600 mb-6">Perfect for trying out StudySnap</p>
              <div className="text-4xl font-bold text-slate-900 mb-6">
                £0<span className="text-lg font-normal text-slate-500">/week</span>
              </div>
              <ul className="space-y-4 mb-8">
                {[
                  '5 flashcards per week',
                  'YouTube video support',
                  'PDF & text upload',
                  'Basic study interface',
                  'Weekly limit resets automatically',
                ].map((feature, i) => (
                  <li key={i} className="flex items-start gap-3 text-slate-600">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button 
                variant="outline" 
                className="w-full"
                disabled={!isSubscribed}
                onClick={() => navigate(isAuthenticated ? '/dashboard' : '/register')}
              >
                {!isSubscribed ? 'Current Plan' : 'Downgrade'}
              </Button>
            </CardContent>
          </Card>

          {/* Unlimited Plan */}
          <Card className={`border-2 ${isSubscribed ? 'border-violet-600' : 'border-violet-600 relative'}`}>
            {!isSubscribed && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </span>
              </div>
            )}
            <CardContent className="p-8">
              {isSubscribed && (
                <div className="inline-block bg-violet-100 text-violet-700 px-3 py-1 rounded-full text-sm font-medium mb-4">
                  Current Plan
                </div>
              )}
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Unlimited</h2>
              <p className="text-slate-600 mb-6">For serious students who want it all</p>
              <div className="text-4xl font-bold text-slate-900 mb-6">
                £2.99<span className="text-lg font-normal text-slate-500">/week</span>
              </div>
              <ul className="space-y-4 mb-8">
                {[
                  'Unlimited flashcards',
                  'YouTube video support',
                  'PDF & text upload',
                  'Priority AI processing',
                  '7-day free trial',
                  'Cancel anytime',
                ].map((feature, i) => (
                  <li key={i} className="flex items-start gap-3 text-slate-600">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button 
                className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                onClick={handleSubscribe}
                disabled={isLoading || isSubscribed}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : isSubscribed ? (
                  <>
                    <Crown className="w-4 h-4 mr-2" />
                    Active
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Start Free Trial
                  </>
                )}
              </Button>
              {!isAuthenticated && (
                <p className="text-sm text-slate-500 text-center mt-3">
                  You'll be asked to create an account
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* FAQ */}
        <div className="mt-16 max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              {
                q: 'What happens after the free trial?',
                a: 'After your 7-day free trial, you\'ll be charged £2.99 per week. You can cancel anytime before the trial ends and won\'t be charged.',
              },
              {
                q: 'Can I cancel my subscription?',
                a: 'Yes, you can cancel your subscription at any time from your dashboard. You\'ll continue to have access until the end of your current billing period.',
              },
              {
                q: 'What happens to my flashcards if I cancel?',
                a: 'Your flashcards are yours to keep! You\'ll always have access to view and study your existing flashcards, even on the free plan.',
              },
              {
                q: 'When does my weekly limit reset?',
                a: 'Your free flashcard limit resets every Monday at midnight UTC.',
              },
            ].map((faq, i) => (
              <div key={i} className="bg-white rounded-lg p-6 shadow-sm">
                <h3 className="font-semibold text-slate-900 mb-2">{faq.q}</h3>
                <p className="text-slate-600">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-16 text-center">
          <div className="flex items-center justify-center gap-6 text-slate-400">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              <span className="text-sm">7-day free trial</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm">Cancel anytime</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              <span className="text-sm">Instant access</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
