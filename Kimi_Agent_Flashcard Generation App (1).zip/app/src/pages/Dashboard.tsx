import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { useFlashcardStore } from '../stores/flashcardStore';
import { useUsageStore } from '../stores/usageStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Brain, 
  Plus, 
  Video, 
  FileText, 
  Type, 
  Loader2, 
  MoreVertical, 
  Trash2, 
  ExternalLink,
  Crown,
  Zap,
  LogOut,
  User,
  BookOpen,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { sets, fetchSets, generateFromText, generateFromYoutube, generateFromFile, deleteSet } = useFlashcardStore();
  const { usage, fetchUsage } = useUsageStore();
  
  const [activeTab, setActiveTab] = useState('sets');
  const [textInput, setTextInput] = useState('');
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [upgradeMessage, setUpgradeMessage] = useState('');

  useEffect(() => {
    fetchSets();
    fetchUsage();
  }, [fetchSets, fetchUsage]);

  const handleGenerateFromText = async () => {
    if (!textInput.trim() || textInput.length < 50) {
      toast.error('Please enter at least 50 characters');
      return;
    }
    
    setIsGenerating(true);
    try {
      const set = await generateFromText(textInput);
      toast.success(`Generated ${set.flashcards.length} flashcards!`);
      setTextInput('');
      setActiveTab('sets');
      fetchUsage();
    } catch (error: any) {
      if (error.response?.data?.upgradeRequired) {
        setUpgradeMessage(error.response.data.message);
        setShowUpgradeDialog(true);
      } else {
        toast.error(error.response?.data?.message || 'Failed to generate flashcards');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateFromYoutube = async () => {
    if (!youtubeUrl.trim()) {
      toast.error('Please enter a YouTube URL');
      return;
    }
    
    setIsGenerating(true);
    try {
      const set = await generateFromYoutube(youtubeUrl);
      toast.success(`Generated ${set.flashcards.length} flashcards!`);
      setYoutubeUrl('');
      setActiveTab('sets');
      fetchUsage();
    } catch (error: any) {
      if (error.response?.data?.upgradeRequired) {
        setUpgradeMessage(error.response.data.message);
        setShowUpgradeDialog(true);
      } else {
        toast.error(error.response?.data?.message || 'Failed to generate flashcards');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateFromFile = async () => {
    if (!uploadedFile) {
      toast.error('Please select a file');
      return;
    }
    
    setIsGenerating(true);
    try {
      const set = await generateFromFile(uploadedFile);
      toast.success(`Generated ${set.flashcards.length} flashcards!`);
      setUploadedFile(null);
      setActiveTab('sets');
      fetchUsage();
    } catch (error: any) {
      if (error.response?.data?.upgradeRequired) {
        setUpgradeMessage(error.response.data.message);
        setShowUpgradeDialog(true);
      } else {
        toast.error(error.response?.data?.message || 'Failed to generate flashcards');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeleteSet = async (id: string) => {
    if (confirm('Are you sure you want to delete this flashcard set?')) {
      await deleteSet(id);
      toast.success('Flashcard set deleted');
    }
  };

  const isSubscribed = user?.subscription?.status === 'ACTIVE';
  const remainingFlashcards = usage?.remaining || 0;
  const weeklyProgress = usage ? (usage.flashcardsGeneratedThisWeek / (isSubscribed ? 100 : 5)) * 100 : 0;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation */}
      <nav className="border-b bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/dashboard')}>
              <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                StudySnap
              </span>
            </div>
            <div className="flex items-center gap-4">
              {!isSubscribed && (
                <Button 
                  variant="outline" 
                  size="sm"
                  className="hidden sm:flex items-center gap-2 border-amber-500 text-amber-600 hover:bg-amber-50"
                  onClick={() => navigate('/pricing')}
                >
                  <Crown className="w-4 h-4" />
                  Upgrade
                </Button>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <User className="w-5 h-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem className="text-slate-500">
                    {user?.email}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/pricing')}>
                    <Crown className="w-4 h-4 mr-2" />
                    {isSubscribed ? 'Manage Subscription' : 'Upgrade'}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={logout} className="text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Usage Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Weekly Usage</CardDescription>
              <CardTitle className="text-2xl">
                {usage?.flashcardsGeneratedThisWeek || 0} / {isSubscribed ? '∞' : '5'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!isSubscribed && (
                <>
                  <Progress value={weeklyProgress} className="h-2" />
                  <p className="text-sm text-slate-500 mt-2">
                    {remainingFlashcards} remaining this week
                  </p>
                </>
              )}
              {isSubscribed && (
                <p className="text-sm text-green-600 mt-2 flex items-center gap-1">
                  <Crown className="w-4 h-4" />
                  Unlimited plan active
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Flashcard Sets</CardDescription>
              <CardTitle className="text-2xl">{sets.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-500">
                {sets.reduce((acc, set) => acc + (set._count?.flashcards || 0), 0)} total flashcards
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Subscription</CardDescription>
              <CardTitle className="text-2xl">
                {isSubscribed ? 'Unlimited' : 'Free'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isSubscribed ? (
                <p className="text-sm text-green-600 flex items-center gap-1">
                  <Zap className="w-4 h-4" />
                  Active
                </p>
              ) : (
                <Button 
                  size="sm" 
                  variant="outline"
                  className="w-full"
                  onClick={() => navigate('/pricing')}
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Unlimited
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="sets" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              My Flashcards
            </TabsTrigger>
            <TabsTrigger value="create" className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Create New
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sets">
            {sets.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-10 h-10 text-slate-400" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No flashcards yet</h3>
                <p className="text-slate-600 mb-6">Create your first flashcard set to start studying</p>
                <Button onClick={() => setActiveTab('create')}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Flashcards
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sets.map((set) => (
                  <Card key={set.id} className="group hover:shadow-lg transition-shadow">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          {set.sourceType === 'YOUTUBE' && <Video className="w-5 h-5 text-red-500" />}
                          {set.sourceType === 'PDF' && <FileText className="w-5 h-5 text-blue-500" />}
                          {set.sourceType === 'TEXT' && <Type className="w-5 h-5 text-slate-500" />}
                          {set.sourceType === 'DOC' && <FileText className="w-5 h-5 text-blue-700" />}
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleDeleteSet(set.id)} className="text-red-600">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      <CardTitle className="text-lg mt-2 line-clamp-2">{set.title}</CardTitle>
                      {set.description && (
                        <CardDescription className="line-clamp-2">{set.description}</CardDescription>
                      )}
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-500">
                          {set._count?.flashcards || 0} flashcards
                        </span>
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => navigate(`/flashcards/${set.id}`)}
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Study
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="create">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Text Input */}
              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-violet-100 rounded-xl flex items-center justify-center mb-4">
                    <Type className="w-6 h-6 text-violet-600" />
                  </div>
                  <CardTitle>Paste Text</CardTitle>
                  <CardDescription>
                    Paste your notes or any text content
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Textarea
                      placeholder="Paste your notes here... (minimum 50 characters)"
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      rows={6}
                    />
                    <Button 
                      className="w-full"
                      onClick={handleGenerateFromText}
                      disabled={isGenerating || textInput.length < 50}
                    >
                      {isGenerating ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Zap className="w-4 h-4 mr-2" />
                      )}
                      Generate Flashcards
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* YouTube */}
              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                    <Video className="w-6 h-6 text-red-600" />
                  </div>
                  <CardTitle>YouTube Video</CardTitle>
                  <CardDescription>
                    Convert any YouTube video with captions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>YouTube URL</Label>
                      <Input
                        placeholder="https://youtube.com/watch?v=..."
                        value={youtubeUrl}
                        onChange={(e) => setYoutubeUrl(e.target.value)}
                      />
                    </div>
                    <Button 
                      className="w-full"
                      onClick={handleGenerateFromYoutube}
                      disabled={isGenerating || !youtubeUrl.trim()}
                    >
                      {isGenerating ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Zap className="w-4 h-4 mr-2" />
                      )}
                      Generate Flashcards
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* File Upload */}
              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle>Upload File</CardTitle>
                  <CardDescription>
                    Upload PDF or text files
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center">
                      <Input
                        type="file"
                        accept=".pdf,.txt"
                        onChange={(e) => setUploadedFile(e.target.files?.[0] || null)}
                        className="hidden"
                        id="file-upload"
                      />
                      <Label 
                        htmlFor="file-upload"
                        className="cursor-pointer flex flex-col items-center"
                      >
                        <Plus className="w-8 h-8 text-slate-400 mb-2" />
                        <span className="text-sm text-slate-600">
                          {uploadedFile ? uploadedFile.name : 'Click to upload PDF or TXT'}
                        </span>
                      </Label>
                    </div>
                    <Button 
                      className="w-full"
                      onClick={handleGenerateFromFile}
                      disabled={isGenerating || !uploadedFile}
                    >
                      {isGenerating ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Zap className="w-4 h-4 mr-2" />
                      )}
                      Generate Flashcards
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {!isSubscribed && remainingFlashcards <= 2 && (
              <Alert className="mt-6 bg-amber-50 border-amber-200">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <AlertDescription className="flex items-center justify-between">
                  <span>
                    You're running low on free flashcards. Upgrade to unlimited for £2.99/week.
                  </span>
                  <Button 
                    size="sm" 
                    onClick={() => navigate('/pricing')}
                    className="bg-amber-600 hover:bg-amber-700"
                  >
                    <Crown className="w-4 h-4 mr-2" />
                    Upgrade
                  </Button>
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Weekly Limit Reached</DialogTitle>
            <DialogDescription>{upgradeMessage}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <Card className="border-violet-600">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Unlimited Plan</h3>
                  <span className="text-2xl font-bold">£2.99<span className="text-sm font-normal">/week</span></span>
                </div>
                <ul className="space-y-2 mb-6">
                  {[
                    'Unlimited flashcards',
                    'Priority AI processing',
                    '7-day free trial',
                  ].map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm">
                      <Zap className="w-4 h-4 text-violet-600" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  className="w-full bg-gradient-to-r from-violet-600 to-indigo-600"
                  onClick={() => navigate('/pricing')}
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Start Free Trial
                </Button>
              </CardContent>
            </Card>
            <Button variant="ghost" className="w-full" onClick={() => setShowUpgradeDialog(false)}>
              Maybe later
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
