import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Brain, 
  Zap, 
  FileText, 
  Video, 
  CheckCircle, 
  ArrowRight,
  Sparkles,
  BookOpen,
  Clock
} from 'lucide-react';

export default function LandingPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                StudySnap
              </span>
            </div>
            <div className="flex items-center gap-4">
              {isAuthenticated ? (
                <Button onClick={() => navigate('/dashboard')}>
                  Go to Dashboard
                </Button>
              ) : (
                <>
                  <Button variant="ghost" onClick={() => navigate('/login')}>
                    Log in
                  </Button>
                  <Button onClick={() => navigate('/register')}>
                    Get Started
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-violet-100 text-violet-700 rounded-full text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              AI-Powered Study Tool
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6 leading-tight">
              Turn Long Videos & Notes Into{' '}
              <span className="bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                Powerful Flashcards
              </span>{' '}
              in Seconds
            </h1>
            <p className="text-xl text-slate-600 mb-8">
              Stop wasting hours making flashcards manually. Upload your content and let AI 
              create concise, study-optimized flashcards that help you learn faster and remember longer.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                onClick={() => navigate(isAuthenticated ? '/dashboard' : '/register')}
              >
                Start Free
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => navigate('/pricing')}
              >
                View Pricing
              </Button>
            </div>
            <p className="text-sm text-slate-500 mt-4">
              Free plan: 5 flashcards/week • No credit card required
            </p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">How It Works</h2>
            <p className="text-lg text-slate-600">Three simple steps to better studying</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Video,
                title: 'Upload Content',
                description: 'Paste a YouTube link, upload a PDF, or paste your notes. We support videos, documents, and text.',
              },
              {
                icon: Sparkles,
                title: 'AI Generates Flashcards',
                description: 'Our AI analyzes your content and creates concise, study-optimized flashcards in seconds.',
              },
              {
                icon: BookOpen,
                title: 'Study & Learn',
                description: 'Review your flashcards with our clean study interface. Flip, navigate, and master the material.',
              },
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-violet-100 to-indigo-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <step.icon className="w-8 h-8 text-violet-600" />
                </div>
                <div className="w-8 h-8 bg-violet-600 text-white rounded-full flex items-center justify-center font-bold mx-auto mb-4">
                  {index + 1}
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">{step.title}</h3>
                <p className="text-slate-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Everything You Need to Study Smarter</h2>
            <p className="text-lg text-slate-600">Powerful features designed for effective learning</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Video,
                title: 'YouTube Support',
                description: 'Convert any YouTube video with captions into flashcards automatically.',
              },
              {
                icon: FileText,
                title: 'Document Upload',
                description: 'Upload PDFs and text files to extract key concepts and definitions.',
              },
              {
                icon: Zap,
                title: 'AI-Powered',
                description: 'Advanced AI identifies the most important information for your studies.',
              },
              {
                icon: Brain,
                title: 'Smart Flashcards',
                description: 'Concise, clear flashcards optimized for quick memorization.',
              },
              {
                icon: Clock,
                title: 'Weekly Limits',
                description: 'Free users get 5 flashcards per week. Upgrade for unlimited access.',
              },
              {
                icon: CheckCircle,
                title: 'Clean Interface',
                description: 'Distraction-free study environment to help you focus on learning.',
              },
            ].map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-violet-100 to-indigo-100 rounded-xl flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-violet-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Simple, Transparent Pricing</h2>
            <p className="text-lg text-slate-600">Start free, upgrade when you need more</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Free Plan */}
            <Card className="border-2 border-slate-200">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Free</h3>
                <p className="text-slate-600 mb-6">Perfect for trying out StudySnap</p>
                <div className="text-4xl font-bold text-slate-900 mb-6">
                  £0<span className="text-lg font-normal text-slate-500">/week</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {[
                    '5 flashcards per week',
                    'YouTube video support',
                    'PDF & text upload',
                    'Basic study interface',
                  ].map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-600">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate(isAuthenticated ? '/dashboard' : '/register')}
                >
                  Get Started
                </Button>
              </CardContent>
            </Card>

            {/* Pro Plan */}
            <Card className="border-2 border-violet-600 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </span>
              </div>
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Unlimited</h3>
                <p className="text-slate-600 mb-6">For serious students who want it all</p>
                <div className="text-4xl font-bold text-slate-900 mb-6">
                  £2.99<span className="text-lg font-normal text-slate-500">/week</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {[
                    'Unlimited flashcards',
                    'YouTube video support',
                    'PDF & text upload',
                    'Priority AI processing',
                    '7-day free trial',
                  ].map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-600">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700"
                  onClick={() => navigate('/pricing')}
                >
                  Start Free Trial
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-violet-600 to-indigo-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Study Smarter?
          </h2>
          <p className="text-xl text-violet-100 mb-8">
            Join thousands of students who are saving time and learning more effectively with StudySnap.
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            className="bg-white text-violet-600 hover:bg-violet-50"
            onClick={() => navigate(isAuthenticated ? '/dashboard' : '/register')}
          >
            Start Free Today
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-slate-900 text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <Brain className="w-6 h-6 text-violet-400" />
              <span className="text-lg font-bold text-white">StudySnap</span>
            </div>
            <div className="flex gap-6">
              <a href="/pricing" className="hover:text-white transition-colors">Pricing</a>
              <a href="/login" className="hover:text-white transition-colors">Login</a>
              <a href="/register" className="hover:text-white transition-colors">Sign Up</a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-800 text-center text-sm">
            © 2024 StudySnap. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
