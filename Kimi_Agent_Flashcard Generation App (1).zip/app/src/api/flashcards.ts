import { apiClient } from './client';

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  order: number;
}

export interface FlashcardSet {
  id: string;
  title: string;
  description: string | null;
  sourceType: 'VIDEO' | 'TEXT' | 'PDF' | 'DOC' | 'YOUTUBE';
  sourceUrl: string | null;
  createdAt: string;
  updatedAt: string;
  flashcards: Flashcard[];
  _count?: {
    flashcards: number;
  };
}

export const flashcardsApi = {
  generateFromText: async (text: string): Promise<{ flashcardSet: FlashcardSet }> => {
    const response = await apiClient.post('/flashcards/generate/text', { text });
    return response.data;
  },

  generateFromYoutube: async (url: string): Promise<{ flashcardSet: FlashcardSet }> => {
    const response = await apiClient.post('/flashcards/generate/youtube', { url });
    return response.data;
  },

  generateFromFile: async (file: File): Promise<{ flashcardSet: FlashcardSet }> => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await apiClient.post('/flashcards/generate/file', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  getSets: async (): Promise<{ flashcardSets: FlashcardSet[] }> => {
    const response = await apiClient.get('/flashcards');
    return response.data;
  },

  getSet: async (id: string): Promise<{ flashcardSet: FlashcardSet }> => {
    const response = await apiClient.get(`/flashcards/${id}`);
    return response.data;
  },

  deleteSet: async (id: string): Promise<{ message: string }> => {
    const response = await apiClient.delete(`/flashcards/${id}`);
    return response.data;
  },
};
