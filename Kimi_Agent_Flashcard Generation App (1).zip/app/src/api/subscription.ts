import { apiClient } from './client';

export interface Subscription {
  id: string;
  status: 'ACTIVE' | 'INACTIVE' | 'CANCELLED' | 'PAST_DUE';
  stripeCustomerId: string | null;
  stripeSubscriptionId: string | null;
  currentPeriodStart: string | null;
  currentPeriodEnd: string | null;
}

export const subscriptionApi = {
  createCheckout: async (): Promise<{ sessionId: string; url: string }> => {
    const response = await apiClient.post('/subscriptions/checkout');
    return response.data;
  },

  getStatus: async (): Promise<{ subscription: Subscription }> => {
    const response = await apiClient.get('/subscriptions/status');
    return response.data;
  },

  cancel: async (): Promise<{ message: string }> => {
    const response = await apiClient.post('/subscriptions/cancel');
    return response.data;
  },
};
