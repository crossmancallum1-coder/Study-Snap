import { apiClient } from './client';

export interface UsageInfo {
  flashcardsGeneratedThisWeek: number;
  weeklyLimit: number;
  remaining: number;
  isSubscribed: boolean;
}

export const usageApi = {
  getUsage: async (): Promise<{ usage: UsageInfo }> => {
    const response = await apiClient.get('/usage');
    return response.data;
  },
};
