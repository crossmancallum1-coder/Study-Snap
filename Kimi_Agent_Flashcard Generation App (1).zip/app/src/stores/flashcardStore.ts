import { create } from 'zustand';
import { flashcardsApi, type FlashcardSet } from '../api/flashcards';

interface FlashcardState {
  sets: FlashcardSet[];
  currentSet: FlashcardSet | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchSets: () => Promise<void>;
  fetchSet: (id: string) => Promise<void>;
  generateFromText: (text: string) => Promise<FlashcardSet>;
  generateFromYoutube: (url: string) => Promise<FlashcardSet>;
  generateFromFile: (file: File) => Promise<FlashcardSet>;
  deleteSet: (id: string) => Promise<void>;
  clearError: () => void;
}

export const useFlashcardStore = create<FlashcardState>((set) => ({
  sets: [],
  currentSet: null,
  isLoading: false,
  error: null,

  fetchSets: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await flashcardsApi.getSets();
      set({ sets: response.flashcardSets, isLoading: false });
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to fetch flashcard sets',
        isLoading: false,
      });
    }
  },

  fetchSet: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const response = await flashcardsApi.getSet(id);
      set({ currentSet: response.flashcardSet, isLoading: false });
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to fetch flashcard set',
        isLoading: false,
      });
    }
  },

  generateFromText: async (text) => {
    set({ isLoading: true, error: null });
    try {
      const response = await flashcardsApi.generateFromText(text);
      const newSet = response.flashcardSet;
      set((state) => ({
        sets: [newSet, ...state.sets],
        currentSet: newSet,
        isLoading: false,
      }));
      return newSet;
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to generate flashcards',
        isLoading: false,
      });
      throw error;
    }
  },

  generateFromYoutube: async (url) => {
    set({ isLoading: true, error: null });
    try {
      const response = await flashcardsApi.generateFromYoutube(url);
      const newSet = response.flashcardSet;
      set((state) => ({
        sets: [newSet, ...state.sets],
        currentSet: newSet,
        isLoading: false,
      }));
      return newSet;
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to generate flashcards',
        isLoading: false,
      });
      throw error;
    }
  },

  generateFromFile: async (file) => {
    set({ isLoading: true, error: null });
    try {
      const response = await flashcardsApi.generateFromFile(file);
      const newSet = response.flashcardSet;
      set((state) => ({
        sets: [newSet, ...state.sets],
        currentSet: newSet,
        isLoading: false,
      }));
      return newSet;
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to generate flashcards',
        isLoading: false,
      });
      throw error;
    }
  },

  deleteSet: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await flashcardsApi.deleteSet(id);
      set((state) => ({
        sets: state.sets.filter((s) => s.id !== id),
        currentSet: state.currentSet?.id === id ? null : state.currentSet,
        isLoading: false,
      }));
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to delete flashcard set',
        isLoading: false,
      });
    }
  },

  clearError: () => set({ error: null }),
}));
