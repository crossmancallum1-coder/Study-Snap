import { create } from 'zustand';
import { usageApi, type UsageInfo } from '../api/usage';

interface UsageState {
  usage: UsageInfo | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchUsage: () => Promise<void>;
  clearError: () => void;
}

export const useUsageStore = create<UsageState>((set) => ({
  usage: null,
  isLoading: false,
  error: null,

  fetchUsage: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await usageApi.getUsage();
      set({ usage: response.usage, isLoading: false });
    } catch (error: any) {
      set({
        error: error.response?.data?.message || 'Failed to fetch usage',
        isLoading: false,
      });
    }
  },

  clearError: () => set({ error: null }),
}));
