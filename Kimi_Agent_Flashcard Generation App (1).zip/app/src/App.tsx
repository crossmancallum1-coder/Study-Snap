import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuthStore } from './stores/authStore';
import { authApi } from './api/auth';

// Pages
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';
import FlashcardViewer from './pages/FlashcardViewer';
import PricingPage from './pages/PricingPage';
import SubscriptionSuccess from './pages/SubscriptionSuccess';

// Components
import { Toaster } from '@/components/ui/sonner';

function App() {
  const { token, setUser, isAuthenticated } = useAuthStore();

  useEffect(() => {
    // Validate token and get user info on app load
    if (token) {
      authApi.getMe()
        .then((response) => {
          setUser(response.user);
        })
        .catch(() => {
          // Token invalid, will be handled by interceptor
        });
    }
  }, [token, setUser]);

  return (
    <Router>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/pricing" element={<PricingPage />} />
        <Route 
          path="/dashboard" 
          element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/flashcards/:id" 
          element={isAuthenticated ? <FlashcardViewer /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/subscription/success" 
          element={isAuthenticated ? <SubscriptionSuccess /> : <Navigate to="/login" />} 
        />
      </Routes>
    </Router>
  );
}

export default App;
